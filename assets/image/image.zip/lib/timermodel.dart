class TimerModel {
  String time;
  double percent;
  TimerModel(this.time, this.percent);
}
